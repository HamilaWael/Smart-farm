import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
import math
from sklearn import metrics


path = "C:\\Users\\ASUS\\Desktop\\"
df_alldata = pd.read_csv(path + 'combined-csv-files.csv')

# Create pandas dataframe to store our time and humidity values
df_alldata = pd.DataFrame(
    {'time_all': df_alldata.index,
     'humidity_all': df_alldata["humidity"]}
)

plt.figure(figsize=(18,10))
plt.scatter(x ="time_all", y ="humidity_all", data = df_alldata)
plt.title("All data", fontsize=30)
plt.xlabel("time (h)",fontsize=20)
plt.ylabel("humidity (%)",fontsize=20)

#Sample - only 200 values between 200 and 294
df_sample = df_alldata[200:294]

# Create pandas dataframe to store our time and humidity values
df_sample = pd.DataFrame(
    {'time': df_sample.index,
     'humidity': df_sample["humidity_all"]})
df_sample

sns.set(font_scale = 2)
p = sns.lmplot(x ="time", y ="humidity", data = df_sample, order = 1, ci = None, height=8, aspect=2)
p.set( xlabel = "time (h)", ylabel = "humidity (%)")
p.set(title='Sample')

# Separating the data into independent and dependent variables
# Converting each dataframe into a numpy array since each dataframe contains only one column

X = np.array(df_sample['time']).reshape(-1, 1)
y = np.array(df_sample['humidity']).reshape(-1, 1)

#Here we splits 75% of the data to training set while 25% of the data to test set
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.25)

regr = LinearRegression()
regr.fit(X_train, y_train)

beta = regr.intercept_
alpha = regr.coef_
print('beta : ', beta)
print('alpha : ', alpha)

#the coefficient of determination of the prediction : R^2
print("Coeff of determination = ", regr.score(X_test, y_test))
print(f"{math.trunc(regr.score(X_test, y_test)*100)}% of the data fit the regression model")

plt.figure(figsize=(14.5, 8))
y_pred = regr.predict(X_test)
plt.scatter(X_test, y_test, color ='b')
plt.plot(X_test, y_pred, color ='k')
plt.show()



print('Mean Absolute Error:', metrics.mean_absolute_error(y_test, y_pred)) #MAE=4 implies that, on average, the forecast's distance from the true value is 4 (e.g true value is 200 and forecast is 196)
print('Mean Squared Error:', metrics.mean_squared_error(y_test, y_pred))
print('Root Mean Squared Error:', np.sqrt(metrics.mean_squared_error(y_test, y_pred)))

'''X_new = [[295]]
y_pred = regr.predict(X_new)
print(y_pred)'''
y_pred = 40
X_new = (y_pred - beta)/(alpha)
print(X_new)