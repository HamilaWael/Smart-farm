import logging
from azure.storage.blob import BlobServiceClient
import azure.functions as func
from datetime import datetime
import logging
import json
import pandas as pd
import pytz

def read_from_blob():

    container_name = 'my-sensor-data'
    connect_str = "DefaultEndpointsProtocol=https;AccountName=appenddata;AccountKey=k6YiBPmKkQpcch8eqTf0YRRqcP8e/RKXTEvCBtdwyOmuWNKIIKk+gC3Hf8JNztzd6M2IZIvucrYUNoiuMnXWyQ==;EndpointSuffix=core.windows.net"
    # Create the BlobServiceClient object which will be used to create a container client
    blob_service_client = BlobServiceClient.from_connection_string(connect_str)

    # Create the container
    container_client = blob_service_client.get_container_client(container_name)

    # List the blobs in the container
    blob_list = container_client.list_blobs()
    res = []
    
    for blob in blob_list:
        res.append(blob.name)
    all_csv = res[-240:]
    print(all_csv)
    df = pd.DataFrame(columns=['date', 'humidity'])
    
    for f in all_csv:
        csv = pd.read_csv(
            f"abfs://{container_name}/{f}",
            storage_options={
                "connection_string": connect_str
            },names=['date','humidity'],index_col=False,encoding='utf8')
        
        df = df.append(csv)
    print(df)
    result = df.to_json(orient="records")
    parsed = json.loads(result)
    data = json.dumps(parsed, indent=4)
    print(data) 
    return data


def main(req: func.HttpRequest) -> func.HttpResponse:
    
    now = datetime.now(pytz.timezone("Europe/Bucharest"))
    dt_string = now.strftime("%d/%m/%Y,%H:00")
    #req_body = req.get_json()
    req_body = {
        "humidity": 57,
        "date": dt_string
    }
    date = dt_string
    humidity = req_body.get('humidity')
    logging.info(f"Save the humidity value {humidity} on {date}.")
    
    if (date and humidity):
        return func.HttpResponse(
            read_from_blob(),
            status_code=200
        )

    else:
        return func.HttpResponse(
                "You need to provide the the following properties in the body of the request : date & humidity",
                status_code=400
        )