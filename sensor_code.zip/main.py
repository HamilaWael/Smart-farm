import ConnectWifi
from machine import Pin, ADC
from time import sleep
import urequests as requests
import ujson as json
import time

url = "https://wael-humidity-sensor-function.azurewebsites.net/api/waelhumiditysensorfunction"

pot = ADC(0)


while True:
  (y, m, d, h, mn, s,ms, t) = time.gmtime()
  pot_value = pot.read()
  moisture_percentage = (100-((pot_value/1023.00) * 100.00));
  
  payload = json.dumps({
  "date": f"{d}/{m}/{y},{h}:{mn}:{s}",
  "humidity": moisture_percentage
  })
  headers = {
      'Content-Type': 'application/json'
  }
    
  response = requests.request("POST", url, headers=headers, data=payload)
  #print(response.text)
  print(f"{moisture_percentage} %")
  sleep(3600)

