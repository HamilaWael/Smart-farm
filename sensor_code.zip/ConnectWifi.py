import gc
from machine import Pin
import network
import esp

try:
  import usocket as socket
except:
  import socket

esp.osdebug(None)

gc.collect()

ssid = 'DIGI-z6RB'
password = 'Aq4SEY3R'

station = network.WLAN(network.STA_IF)

station.active(True)
station.connect(ssid, password)

while station.isconnected() == False:
    pass

print('Connected to wifi successfully ...')
