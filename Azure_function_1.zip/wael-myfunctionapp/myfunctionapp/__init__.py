from azure.storage.blob import BlockBlobService
import logging
import json
import azure.functions as func
import pandas as pd
import io
from datetime import datetime 
import pytz
import smtplib
from smtplib import SMTP

SENDER = "smartfarmupb@gmail.com"
PASSWORD = "Smartsmartfarmfarm12345**"
DESTINATION = 'waelhmila1996@gmail.com'

containerName = "my-sensor-data"


def send_email(subject,msg):
    try:
        server = smtplib.SMTP('smtp.gmail.com:587')
        server.ehlo()
        server.starttls()
        server.login(SENDER, PASSWORD)
        message = 'Subject: {}\n\n{}'.format(subject, msg)
        server.sendmail(SENDER, DESTINATION , message)
        server.quit()
        print("Success: Email sent!")
    except:
        print("Email failed to send")

def csvtoblob(date_val,humidity_val,containerName):  
    
    accountName = "appenddata"
    accountKey = "k6YiBPmKkQpcch8eqTf0YRRqcP8e/RKXTEvCBtdwyOmuWNKIIKk+gC3Hf8JNztzd6M2IZIvucrYUNoiuMnXWyQ=="
  
    now = datetime.now(pytz.timezone("Europe/Bucharest"))
    dt_string = now.strftime("%Y/%m/%d--%H:%M:%S")

    output = io.StringIO()

    l = [[date_val, humidity_val]]
    df = pd.DataFrame (l)
    output = df.to_csv (index_label=False,index=False,encoding = "utf-8",header=False)

    blobService = BlockBlobService(account_name=accountName, account_key=accountKey)
    blobService.create_blob_from_text(containerName, dt_string+'.csv', output)

def saveSensorData(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    now = datetime.now(pytz.timezone("Europe/Bucharest"))
    dt_string = now.strftime("%d/%m/%Y,%H:00")
    req_body = req.get_json()
    date = dt_string
    humidity = req_body.get('humidity')
    
    
    subject = "Irrigation reminder [Mint]"
    msg = f"Hi there,\n\nGet the hell out and irrigate your plant !!\n\nThe humidity value is less than 60%.\n(Current humidity :{humidity}%)\n\nHave a nice day,"

    if humidity < 60 :
        send_email(subject, msg)

    
    if (date and humidity):
        
        logging.info(f"Save the humidity value {humidity} on {date}.")
        return func.HttpResponse(
            f"humidity value {humidity} processed on {date} is saved in the database {csvtoblob(date,humidity,containerName)}",
            status_code=200
        )

    else:
        return func.HttpResponse(
             "You need to provide the the following properties in the body of the request : date & humidity",
             status_code=400
        )

def main(req: func.HttpRequest) -> func.HttpResponse:
    return saveSensorData(req)