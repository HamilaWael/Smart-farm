import datetime
import pytz

import pandas as pd


humidity = 58

def trained_model():

    container_name = 'my-sensor-data'
    connect_str = "DefaultEndpointsProtocol=https;AccountName=appenddata;AccountKey=k6YiBPmKkQpcch8eqTf0YRRqcP8e/RKXTEvCBtdwyOmuWNKIIKk+gC3Hf8JNztzd6M2IZIvucrYUNoiuMnXWyQ==;EndpointSuffix=core.windows.net"
    

    file_name = f"abfs://{container_name}/model_pkl"
    lr = pd.read_pickle(file_name)
    return lr

def pred():

    lr =trained_model()

    beta = lr.intercept_
    alpha = lr.coef_   
    
    X_new = (humidity - beta)/(alpha)
    
    X_new_new = X_new[0]
    hum = X_new_new.item(0)

    current_date_and_time = datetime.datetime.now(pytz.timezone("Europe/Bucharest"))
    hours_added = datetime.timedelta(hours = hum)
    future_date_and_time = current_date_and_time + hours_added

    return print(f"Hi there,\n\nThe humidity value is less than 60%.\n(Current humidity :{humidity}%)\n\nYou have to irrigate your plant on the {future_date_and_time.day}/{future_date_and_time.month}/{future_date_and_time.year} at {future_date_and_time.hour} o'clock !!\n\nHave a nice day,")

msg = pred()
if humidity < 60:
    msg





def trained_model():

    container_name = 'my-sensor-data'

    file_name = f"abfs://{container_name}/model_pkl"
    lr = pd.read_pickle(file_name)

    return lr

#predict irrigation time
lr =trained_model()

beta = lr.intercept_
alpha = lr.coef_   

X_new = (humidity - beta)/(alpha)

X_new_new = X_new[0]
hum = X_new_new.item(0)

current_date_and_time = datetime.datetime.now(pytz.timezone("Europe/Bucharest"))
hours_added = datetime.timedelta(hours = hum)
future_date_and_time = current_date_and_time + hours_added

